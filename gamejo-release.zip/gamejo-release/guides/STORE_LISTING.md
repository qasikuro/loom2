# GameJo — Google Play Store Listing Text

## App Name
GameJo

## Short Description (max 80 characters)
A dreamy journal, manga stories & character log inspired by Sky.

## Full Description (max 4000 characters)
GameJo is a calm, beautiful space to capture your daily moments — inspired by the dreamlike world of Sky: Children of the Light.

✦ PRIVATE JOURNAL
Write freely in your personal diary. Every entry is completely private — just for you. Add a mood, attach a photo, and let daily writing prompts inspire you.

✦ MANGA STORIES
Create beautiful multi-panel manga-style chapters to share with the community. Add images, write narration, set a mood and location. Others can "Witness" your story — a gentler way to show appreciation.

✦ CHARACTER PROFILE
Build your own character. Set your name, bio, @username, and personality traits. Log your outfits with photos, tags, and dates. Control what the world sees with a simple public/private toggle.

✦ DISCOVER
Explore stories from other players. Find creators by mood — Soft, Lonely, Romantic, Chaotic, Peaceful, Adventurous, Dreamy, or Hopeful. Follow the people whose stories move you. No like counts, no follower pressure — just quiet, meaningful connection.

✦ DESIGNED FOR CALM
- No likes — only "Witnessed" and "Saved"
- No follower counts shown publicly
- No algorithmic stress
- Soft sky gradients that change with the time of day
- Available in 12 languages

GameJo is for the dreamers, the storytellers, and the quiet souls who want a beautiful space to be themselves.

## Category
Lifestyle

## Content Rating
Everyone (E) — suitable for all ages
(No violence, no mature content)

## Tags / Keywords
journal, diary, manga, stories, character, sky, dreamy, social, creative, writing

---

## Required Graphics Sizes

| Asset | Size | File |
|-------|------|------|
| App Icon | 512 x 512 px PNG | icon_512x512.png |
| Feature Graphic | 1024 x 500 px PNG | Create from splash_screen.png |
| Phone Screenshots | Min 320px wide, max 3840px | At least 2 required |
| Tablet Screenshots | Optional | Recommended for tablet listing |

## Screenshots — What to Capture
Take these screenshots from the Expo Go app or a real Android device:

1. **Home screen** — the sky gradient hero with welcome message
2. **Journal screen** — showing a few diary entries
3. **Create story** — the manga panel builder with an image
4. **Discover screen** — the social feed with story cards
5. **Profile screen** — character profile with traits and outfits

## Content Rating Questionnaire Answers (IARC)
When Google asks about content:
- Does the app contain violence? **No**
- Does the app contain sexual content? **No**
- Does the app allow user-generated content? **Yes** (stories and journal entries)
- Does the app contain social features? **Yes** (follow, discover)
- Is the app targeted at children under 13? **No**
