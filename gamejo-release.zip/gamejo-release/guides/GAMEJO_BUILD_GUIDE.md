# GameJo — Complete Build & Release Guide

## Overview
GameJo is a mobile journaling app built with Expo (React Native).
- **Bundle ID (Android):** com.gamejo.app
- **App Name:** GameJo
- **Version:** 1.0.0
- **EAS Project ID:** 95bfb37d-2b50-4ab2-abea-799b09a08144
- **GitHub Repo:** github.com/qasikuro/loom2
- **Production API:** https://loom-qasiland.replit.app/api

---

## PART 1 — First Time Setup (do once)

### 1. Create an Expo Account
1. Go to https://expo.dev
2. Click "Sign Up" — use your email
3. Verify your email

### 2. Get an Expo Access Token
1. Go to https://expo.dev/settings/access-tokens
2. Click "Create Token"
3. Name it "gamejo-build"
4. Copy the token — **save it somewhere safe, you only see it once**

### 3. Create a Google Play Developer Account
1. Go to https://play.google.com/console
2. Pay the one-time $25 fee
3. Complete account setup

---

## PART 2 — Building the Android AAB (every release)

### Method: Build via Expo Website (Easiest)

1. Go to https://expo.dev and sign in
2. Open your GameJo project
3. Click **Builds** → **"Start a build"**
4. Connect GitHub repo: `qasikuro/loom2`
5. Set root directory: `artifacts/sky-journal`
6. Platform: **Android**
7. Profile: **production**
8. Click **Build**
9. Wait ~15 minutes
10. Download the `.aab` file from the build page

### Method: Build via Replit Shell (Alternative)

Open the Shell tab in Replit and run:

```bash
export EXPO_TOKEN=YOUR_TOKEN_HERE
cd ~/workspace/artifacts/sky-journal
npx eas-cli@latest build --platform android --profile production --non-interactive
```

---

## PART 3 — Uploading to Google Play Store

### First Upload (New App)

1. Go to https://play.google.com/console
2. Click **"Create app"**
3. Fill in:
   - App name: **GameJo**
   - Default language: **English**
   - App or game: **App**
   - Free or paid: **Free**
4. Click "Create app"

### Store Listing Setup
1. Go to **Store presence → Main store listing**
2. Fill in app name, description (see STORE_LISTING.md)
3. Upload screenshots (at least 2 phone screenshots required)
4. Upload the feature graphic (1024 x 500 px)
5. Upload the app icon (512 x 512 px) — use `icon_512x512.png`

### Upload the AAB file
1. Go to **Release → Production**
2. Click **"Create new release"**
3. Upload the `.aab` file from EAS
4. Fill in release notes
5. Click **"Review release"** → **"Start rollout to Production"**

---

## PART 4 — Updating the App (future versions)

### Step 1 — Make your code changes in Replit

### Step 2 — Bump the version number
Edit `artifacts/sky-journal/app.json`:
```json
"version": "1.1.0",
"android": {
  "versionCode": 2
}
```
*(increase versionCode by 1 each release, e.g. 1→2→3)*

### Step 3 — Build new AAB (same as Part 2)

### Step 4 — Upload to Play Console
1. Go to **Release → Production**
2. Click **"Create new release"**
3. Upload the new `.aab`
4. Write what changed in release notes
5. Submit for review

---

## PART 5 — Key Files Reference

| File | What it does |
|------|-------------|
| `artifacts/sky-journal/app.json` | App name, version, bundle ID, EAS project ID |
| `artifacts/sky-journal/eas.json` | Build profiles (production, preview) |
| `artifacts/sky-journal/app.config.ts` | API URL, Clerk key, environment config |
| `lib/db/src/schema/` | Database tables |
| `artifacts/api-server/src/routes/` | Backend API routes |
| `.github/workflows/eas-build-android.yml` | GitHub Actions auto-build |

---

## PART 6 — Troubleshooting

### "Bearer token is invalid"
→ Your EXPO_TOKEN expired. Get a new one at expo.dev/settings/access-tokens

### "ERR_PNPM_LOCKFILE_CONFIG_MISMATCH"
→ Run in shell: `cd ~/workspace && pnpm install --no-frozen-lockfile`
→ Then push to GitHub

### "versionCode must be higher than previous"
→ Increase `versionCode` in app.json (e.g. 1 → 2)

### App crashes on launch
→ Check API server is running at https://loom-qasiland.replit.app/api/health

---

## PART 7 — Important Accounts & Links

| Service | URL | What for |
|---------|-----|----------|
| Expo | expo.dev | Build the Android APK/AAB |
| GitHub | github.com/qasikuro/loom2 | Code storage |
| Google Play | play.google.com/console | Publish the app |
| Replit | replit.com | Code editing & API server |
| Clerk | clerk.com | User login/authentication |
