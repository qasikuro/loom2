# GameJo — Quick Reference Card

## Build a new Android AAB (every update)

1. Open https://expo.dev → your project
2. Builds → Start a build → Android → production
3. Download .aab when done (~15 min)

## Upload to Google Play

1. play.google.com/console → GameJo app
2. Release → Production → Create new release
3. Upload the .aab file
4. Bump versionCode in app.json (1 → 2 → 3...)

## Change app version before building

File: `artifacts/sky-journal/app.json`
```
"version": "1.1.0",        ← user-visible version
"versionCode": 2            ← must go up by 1 each time
```

## Key credentials needed

| What | Where to get it |
|------|----------------|
| Expo Token | expo.dev/settings/access-tokens |
| Google Play | play.google.com/console |
| Clerk Keys | dashboard.clerk.com |

## Production API URL
https://loom-qasiland.replit.app

## GitHub Repo
https://github.com/qasikuro/loom2
