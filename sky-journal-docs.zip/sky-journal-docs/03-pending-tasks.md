# Sky Journal — Pending Tasks (Proposed)

All tasks below are in PROPOSED status — not yet started. Grouped by theme for easy prioritisation.

---

## SEASON & EVENTS (Admin-facing)

### Task #21 — Seasonal Countdown in App
**Goal:** Show players a live countdown so they know when the current season ends.
**Where:** Mobile app home screen or profile screen.
**Effort:** Low-Medium. Requires reading the active event's `endsAt` timestamp from `/api/admin/events` (active status) and displaying a countdown timer.

### Task #22 — Admin Visibility into Live Seasonal Items
**Goal:** Give the admin panel a clear view of which seasonal items are active right now.
**Where:** Admin → Events page.
**Effort:** Low. Add a highlighted "Currently Live" section at the top of the Events list, showing the active event's inventory items in a readable format.

### Task #23 — Edit Seasonal Items Without Redeploying
**Goal:** Admins can add or edit seasonal items on an active event without needing a server redeploy.
**Where:** Admin → Events → Edit form.
**Effort:** Medium. The backend PUT route and form already exist; this task likely involves making inventory items editable on an *active* event (currently may be locked), with validation.

---

## SOCIAL — TITLES & PROFILES

### Task #26 — Show Earned Titles on Other Players' Profiles (Discover Feed)
**Goal:** When viewing a DiscoverCard or another user's profile, display their active earned title.
**Where:** DiscoverCard component + FriendProfileSheet.
**Effort:** Low-Medium. Title is stored on the character record. Ensure it's included in discover feed API response and rendered on the card.

### Task #27 — Preview What Each Title Means Before Choosing
**Goal:** Users can tap a title in the title selector to read a description before equipping it.
**Where:** Mobile app → Profile → Title selector modal.
**Effort:** Low. Add a description field to the title catalogue and render a tooltip/modal on tap.

---

## ANIMATIONS & UI POLISH

### Task #32 — Smoother Progress Bar Ease-in on Profile Tab Return
**Goal:** When the user returns to the Profile tab, progress bars ease in smoothly instead of snapping.
**Where:** `artifacts/sky-journal/components/profile/` progress bar components.
**Effort:** Low. Add an entrance animation (e.g. Animated.timing with easing) triggered on tab focus.

### Task #33 — Stagger Progress Bar Row Entrance
**Goal:** Each progress bar row enters slightly after the previous one (stagger effect).
**Where:** Same as Task #32.
**Effort:** Low. Add staggered delays (e.g. index × 80ms) to each bar's entrance animation.

---

## CONTENT & COPY

### Task #60 — Split the About Section into Manageable Sections
**Goal:** The About / info section (likely in the guide or profile area) is too long — split into collapsible or paginated sections.
**Where:** Guide pages or onboarding overlay.
**Effort:** Low. Restructure content into sections with expand/collapse UI.

---

## THEME CONSISTENCY

### Task #61 — Keep Journal and Story Cards Consistent When Switching Themes
**Goal:** When the user switches visual themes, journal cards and story cards should update consistently without visual glitches.
**Where:** `components/JournalCard.tsx`, `components/DiscoverCard.tsx`, ThemeContext.
**Effort:** Low-Medium. Audit card components to ensure all colours come from ThemeContext rather than hardcoded values.

---

## CAMPFIRE & REAL-TIME

### Task #65 — Show Who Else Is in a Campfire Room Right Now
**Goal:** Display a list (or avatar row) of currently present users in the campfire room.
**Where:** `app/campfire/` screen.
**Effort:** Medium. Requires SSE presence events or a polling endpoint. Backend needs to track room presence (join/leave events). Frontend renders a "currently here" indicator.

### Task #66 — Keep SSE Working After App Wakes from Background
**Goal:** When the app resumes from background, the SSE connection re-establishes automatically.
**Where:** SSE connection logic in AppContext or a dedicated hook.
**Effort:** Medium. Use AppState listener (`AppState.addEventListener('change', ...)`) to detect foreground transition and reconnect the SSE stream.

### Task #67 — Live Unread Badge on Messages Tab via SSE
**Goal:** When a new DM arrives via SSE, the Messages tab shows a live unread count badge without a manual refresh.
**Where:** Tab bar + SSE event handler.
**Effort:** Low-Medium. SSE already delivers new-message events; wire the count into tab bar badge state.

---

## DATA INTEGRITY & VALIDATION

### Task #70 — Validate the Guides Endpoint
**Goal:** The `/api/guide` endpoint should validate its response shape so corrupted guide data can't silently break the app.
**Where:** `artifacts/api-server/src/routes/guides.ts`.
**Effort:** Low. Add Zod schema validation to the route response before sending.

### Task #71 — Clear Error Message for Corrupted Story/Journal Data
**Goal:** When story or journal data from the API is malformed, show the user a friendly error rather than a blank screen.
**Where:** Story reader, journal list.
**Effort:** Low. Add try/catch + ErrorFallback rendering around data parsing.

### Task #72 — Fix TypeScript Notification Type Mismatch in App Layout
**Goal:** There is a known TS type error in `_layout.tsx` related to notification types.
**Where:** `artifacts/sky-journal/app/_layout.tsx`.
**Effort:** Low. Align the notification response type with what Expo Notifications actually returns.

### Task #73 — Reset Staleness Timestamps on User Save/Delete
**Goal:** When the user saves or deletes their own content, staleness timestamps should reset so the app doesn't show a "refreshing" indicator unnecessarily.
**Where:** AppContext mutation handlers.
**Effort:** Low. After a successful save/delete, update the relevant staleness timestamp in context.

### Task #74 — Subtle "Refreshing…" Indicator for Stale Data
**Goal:** When stale data is being quietly updated in the background, show a subtle non-blocking indicator (e.g. a small spinner in the header).
**Where:** List screens (Journal, Stories, Discover, Outfits).
**Effort:** Low. Add a isFetching boolean to context and render a subtle indicator.

### Task #75 — Cover Error Paths for Corrupted API Responses
**Goal:** Corrupted or unexpected API responses should not silently disappear — show appropriate error states.
**Where:** AppContext data loading, individual list screens.
**Effort:** Medium. Add explicit error boundary coverage and error state UI to all list/detail screens.

---

## TESTING

### Task #76 — Tests for Discover Feed and Follow/Unfollow Flows
**Goal:** Add automated tests covering the discover feed ranking and the follow/unfollow API + UI flows.
**Where:** `lib/` or `artifacts/api-server` test directory.
**Effort:** Medium. Write integration tests for `/api/discover` scoring logic and follow/unfollow endpoints.

---

## IMAGE & MEDIA

### Task #77 — Better Error Handling for Image Upload Failures
**Goal:** When an image upload fails, show a clear error message instead of a blank/silent failure.
**Where:** Image upload logic in AppContext + picker modals.
**Effort:** Low. Add error catch on the upload POST and surface a Toast or inline error to the user.

---

## ADDITIONAL PROPOSED TASKS (beyond the 21 shown)

The system shows 16 more tasks not listed above. Based on the project scope, likely candidates include:

- Wardrobe / cosmetic item previews
- Sticker animation improvements
- Drift (AI) conversation history persistence
- Constellation map interactivity
- Push notification deep linking
- Onboarding flow completion tracking
- Admin dashboard analytics (DAU, MAU, content volume)
- Story save / bookmark flow
- User blocking / muting
- Content moderation auto-flagging
- Profile share link / QR code
- Campfire room creation by users
- Story collaboration (multi-author)
- Seasonal achievement badges

---

## Priority Recommendation

| Priority | Tasks | Reason |
|---|---|---|
| **Critical (fix now)** | #72, #70, #71 | Type errors and validation gaps cause runtime crashes |
| **High (user-facing)** | #66, #67, #65 | Real-time features broken in background degrade core UX |
| **High (trust)** | #73, #74, #75, #77 | Data integrity and visible errors affect user confidence |
| **Medium (polish)** | #26, #27, #32, #33, #61 | Improve social and visual quality |
| **Medium (admin)** | #21, #22, #23 | Season features need admin tooling to be useful |
| **Low (content)** | #60, #76 | Content and test coverage — important but not blocking |
