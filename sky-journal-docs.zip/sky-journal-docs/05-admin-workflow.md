# Sky Journal — Admin Panel: Current State & Remaining Work

---

## What the Admin Panel Is

The Sky Journal Admin is a separate web app (`artifacts/admin`) accessible at `/admin/`. It is a private operations dashboard for managing the Sky Journal platform. It runs as a React + Vite app, authenticated via Clerk with an admin role check.

**URL in production:** `https://your-domain.replit.app/admin/`

---

## Admin Authentication

- Login via Clerk (same Clerk tenant as the mobile app)
- First user to log in can self-claim admin access ("Claim first-admin access" button)
- Subsequent users must have admin role granted by an existing admin
- Access Denied screen shown to non-admin Clerk users

---

## Current Admin Pages

### 1. Dashboard
**Status: Built**
- Platform overview stats
- Quick snapshot of users, content, and activity

### 2. Users
**Status: Built**
- List all users
- View user profiles
- Filter and search

### 3. Content
**Status: Built**
- Review public stories
- Review flagged/reported content
- Moderation actions

### 4. Events (Most Feature-Rich)
**Status: Built — some features remaining**

#### What's built:
- Full event list grouped by status: Active → Drafts → Ended
- Create event form: title, description, theme (spring/summer/autumn/winter/special), date range, status
- Edit event form (inline or modal)
- AI inventory generation: click "Generate with AI" + optional context note → Claude returns 4–7 themed items (stars/aura/memory shards/cosmetics)
- Per-item inline editor: type selector, amount/id/name fields
- "Grant to All Users" with two-tap confirm guard → result summary shown
- Delete event

#### Item types supported:
| Type | Field | Grant behaviour |
|---|---|---|
| stars | amount | Upserted into `user_rewards` (adds to balance) |
| aura | amount | Upserted into `user_rewards` |
| memory_shards | amount | Upserted into `user_rewards` |
| cosmetic_item | id + name | Inserted into `user_purchases` (skip if owned) |

#### Remaining / Pending (Tasks #21–23):
- **Task #21:** App-side countdown — show players when the active season ends (requires reading active event from `/api/admin/events?status=active` in the mobile app)
- **Task #22:** Admin visibility into live items — highlight active event inventory more prominently on the Events page; show a "Currently Live" banner at the top
- **Task #23:** Allow editing seasonal items on an active event — currently may prevent editing once granted; make inventory fields editable on active events with a warning

### 5. Reports
**Status: Built**
- Queue of user-submitted content reports
- View flagged content
- Admin can dismiss or take action

---

## Admin API Routes

All admin routes require admin-level Clerk JWT.

| Method | Path | Purpose |
|---|---|---|
| GET | `/api/admin/events` | List all events (all statuses) |
| POST | `/api/admin/events` | Create new event |
| PUT | `/api/admin/events/:id` | Update event (title, dates, inventory, status) |
| DELETE | `/api/admin/events/:id` | Delete event |
| POST | `/api/admin/events/generate-inventory` | AI generates themed inventory suggestions |
| POST | `/api/admin/events/:id/grant` | Grant event inventory to all users |
| GET | `/api/admin/users` | List all users |
| GET | `/api/admin/content` | Content review (stories, etc.) |
| GET | `/api/admin/reports` | Reports queue |
| POST | `/api/admin` | Admin setup (first-admin claim) |

---

## Admin Workflow: Creating a Seasonal Event End-to-End

1. **Go to Admin → Events**
2. Click **"New Event"**
3. Fill in: Title, Description, Theme (season), Start Date, End Date, Status = Draft
4. Click **"Generate with AI"** — optionally add a context note (e.g. "Winter solstice, focus on warmth and memory")
5. Review the 4–7 generated inventory items. Edit amounts or types as needed.
6. Save the event as **Draft**
7. When ready to launch: change Status to **Active** and save
8. Players will see the event (and eventually a countdown — pending Task #21)
9. When the event period ends, click **"Grant to All Users"** — confirm with two-tap → rewards distributed
10. Change Status to **Ended**

---

## Remaining Admin Work (Prioritised)

### High Priority

#### Show "Currently Live" Banner (Task #22)
- At the top of the Events page, show a highlighted card for the active event
- Display: event name, time remaining (countdown), inventory items that will be granted
- Gives admin confidence about what players are seeing right now

#### Allow Editing Active Event Inventory (Task #23)
- Unlock the inventory editor on active events
- Show a warning: "Changes to active events take effect immediately"
- Validate that required fields (amount, type) are not blank before saving
- Do NOT allow deleting items already partially granted

### Medium Priority

#### Admin Analytics Enhancements
- Not in the pending task list but needed for healthy operations:
  - Daily/monthly active users chart
  - Stories created per day
  - Witness events per day
  - Most popular moods in journal entries
  - Top players by engagement score

#### Content Moderation Queue Improvements
- Auto-flag stories with reports > threshold
- One-click "Remove + Notify User" action
- Bulk dismiss

#### User Management Enhancements
- Grant/revoke admin access from UI (currently only first-claim exists)
- View user's full activity (stories, journal count, outfits)
- Soft-ban / restrict user

### Low Priority

#### Admin Notifications
- Email or in-admin alert when a report comes in
- Alert when grant operation completes

#### Export Tools
- Export user list to CSV
- Export event grant history to CSV

---

## Admin Panel Tech Notes

- Built with React + Vite + Tailwind + shadcn/ui
- Uses `@clerk/clerk-react` for auth
- All API calls attach Bearer token from Clerk
- Runs at `/admin/` path — shared proxy routes correctly
- No native dependencies — pure web app

---

## Deployment Note

The admin panel is part of the same monorepo and deploys alongside the API server and mobile app. No separate deploy is needed — publishing the project on Replit publishes all artifacts including the admin panel.

**Access control is your first line of defence:** only Clerk users with admin metadata can access the admin panel. The API server also validates admin status on every admin route.
