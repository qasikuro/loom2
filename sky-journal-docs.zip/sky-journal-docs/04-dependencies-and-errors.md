# Sky Journal — Dependencies, Known Issues & Suggested Workload

---

## Key Dependencies

### Mobile App (`artifacts/sky-journal`)

| Package | Version / Notes | Purpose |
|---|---|---|
| expo | SDK 54 | Mobile app framework |
| react-native | 0.81 | Core mobile runtime |
| expo-router | File-based navigation | App routing |
| @clerk/expo | v3 | Authentication |
| @tanstack/react-query | Data fetching + caching | API state management |
| @react-native-async-storage/async-storage | Offline cache | Data persistence |
| expo-image-picker | Image selection | Camera/gallery picker |
| expo-linear-gradient | Sky gradients | Visual effects |
| expo-notifications | Push notifications | Alerts |
| expo-av | Audio playback | Ambient sounds |
| @expo-google-fonts/inter | Typography | Font loading |
| react-native-keyboard-controller | Keyboard handling | Input UX |
| @expo/vector-icons (Feather) | Icons | Tab bar + UI icons |

### API Server (`artifacts/api-server`)

| Package | Purpose |
|---|---|
| express | HTTP server |
| @clerk/express | JWT auth middleware |
| drizzle-orm | ORM |
| pg (node-postgres) | PostgreSQL client |
| @anthropic-ai/sdk | Claude AI (Drift + events) |
| zod | Input validation |
| multer / busboy | File upload handling |
| pino | Structured logging |

### Admin Panel (`artifacts/admin`)

| Package | Purpose |
|---|---|
| react + vite | Frontend framework |
| @clerk/clerk-react | Auth |
| tailwindcss | Styling |
| shadcn/ui | Component library |
| @tanstack/react-query | Data fetching |

### Shared Libraries

| Library | Purpose |
|---|---|
| `lib/db` | Drizzle ORM schema + PostgreSQL client |
| `lib/api-spec` | OpenAPI 3.1 spec (source of truth for API contract) |
| `lib/api-client-react` | Auto-generated React Query hooks from OpenAPI |
| `lib/api-zod` | Auto-generated Zod schemas from OpenAPI |

### Monorepo Tooling

| Tool | Purpose |
|---|---|
| pnpm workspaces | Package management |
| TypeScript (strict) | Type safety across all packages |
| ESLint (flat config, v10) | Linting (unused vars, explicit any, unsafe imports) |
| drizzle-kit | DB schema push/migrate |

---

## Known Issues & Warnings (Non-breaking)

### 1. Pre-existing TS Errors in `utils/persistImage.ts`
- **Location:** `artifacts/sky-journal/utils/persistImage.ts`
- **Issue:** expo-file-system type definitions don't fully match usage
- **Impact:** None — safe to ignore, not from our changes
- **Fix:** Would require patching expo-file-system types or using `as any` cast

### 2. React Native Web Deprecation Warnings
- **Warnings:** `shadow*`, `textShadow*` style props deprecated
- **Source:** Third-party packages (not our code)
- **Impact:** Console noise only — no functional impact
- **Fix:** Cannot be fixed — upstream packages need to update

### 3. `props.pointerEvents is deprecated` Warning
- **Source:** expo-linear-gradient internals
- **Impact:** Browser console noise only
- **Fix:** Cannot fix — our own code already uses `style={{ pointerEvents: 'none' }}`

### 4. TypeScript Notification Type Mismatch (Task #72)
- **Location:** `artifacts/sky-journal/app/_layout.tsx`
- **Issue:** Notification response type from Expo Notifications doesn't align with our declared type
- **Impact:** TypeScript compile warning; may cause runtime mismatch in notification handling
- **Fix:** Align the type declaration with actual Expo Notifications response shape

### 5. Campfire Route Params Type Issue (Documented)
- **Location:** `artifacts/api-server/src/routes/campfire.ts`
- **Issue:** `req.params.roomId` arrives as `string | string[]` from Express but Drizzle expects plain `string`
- **Fix Applied:** Cast `req.params.roomId as string` — documented in memory

### 6. ClerkProvider Must Be Unconditional
- **Location:** `artifacts/sky-journal/app/_layout.tsx`
- **Rule:** Never gate ClerkProvider behind any condition — @clerk/expo v3 uses internal signals that crash if ClerkProvider renders conditionally
- **Status:** Correctly implemented; must remain this way

### 7. iOS Modal Stacking (Image Picker)
- **Location:** Image picker calls after Modal dismiss
- **Rule:** Wait 400ms (`setTimeout`) before calling `launchImageLibraryAsync` after a Modal closes
- **Status:** Correctly implemented; must be maintained in any new picker integrations

### 8. Alert.alert Does Not Work in Expo Web
- **Rule:** Never use `Alert.alert` for destructive confirms — use inline two-tap confirm pattern
- **Status:** All existing screens use inline confirm; new screens must follow this pattern

---

## Environment Requirements

| Variable | Where | Purpose |
|---|---|---|
| `CLERK_SECRET_KEY` | API server | Clerk JWT verification |
| `EXPO_PUBLIC_CLERK_PUBLISHABLE_KEY` | Mobile app | Clerk client init |
| `DATABASE_URL` | API server + lib/db | PostgreSQL connection |
| `ANTHROPIC_API_KEY` | API server | Claude AI (Drift + events) |
| `REPLIT_DEV_DOMAIN` | Mobile app config | API URL at bundle time |

---

## Suggested Workload by Phase

### Phase 1 — Stability & Correctness (1–2 weeks)
Fix issues that can cause crashes or silent failures before any new features.

| Task | Effort | Impact |
|---|---|---|
| Fix TS notification type (#72) | 1 hour | Prevents potential runtime crash |
| Add Zod validation to guides route (#70) | 2 hours | Prevents silent data corruption |
| Add error states for corrupted story/journal data (#71) | 3 hours | Prevents blank screens |
| Better image upload error messaging (#77) | 2 hours | User-facing clarity |
| Reset staleness timestamps on mutation (#73) | 2 hours | Avoids unnecessary refresh flicker |
| Show "Refreshing…" indicator (#74) | 2 hours | Trust signal for users |
| Cover API response error paths (#75) | 4 hours | Resilience |

### Phase 2 — Real-time & Social Reliability (1 week)
Ensure the live features work correctly after app background/foreground cycles.

| Task | Effort | Impact |
|---|---|---|
| SSE reconnect on app wake (#66) | 4 hours | Campfire and DMs stay live |
| Unread badge via SSE (#67) | 3 hours | Messaging feels instant |
| Campfire presence list (#65) | 6 hours | Social warmth in rooms |

### Phase 3 — Polish & Social Features (1 week)
Improve the visual and social quality of existing features.

| Task | Effort | Impact |
|---|---|---|
| Progress bar ease-in animation (#32) | 2 hours | Profile feels polished |
| Progress bar stagger (#33) | 1 hour | Delightful entrance |
| Theme consistency for cards (#61) | 3 hours | Visual consistency |
| Titles on Discover cards (#26) | 3 hours | Social identity |
| Title preview before choosing (#27) | 2 hours | Informed choice |

### Phase 4 — Admin & Season Features (1 week)
Make seasonal events fully operational end-to-end.

| Task | Effort | Impact |
|---|---|---|
| Season countdown in app (#21) | 3 hours | Players feel season urgency |
| Admin live items visibility (#22) | 2 hours | Admin confidence |
| Edit seasonal items without redeploy (#23) | 4 hours | Operational flexibility |

### Phase 5 — Content & Testing (ongoing)
Content improvements and test coverage.

| Task | Effort | Impact |
|---|---|---|
| Split About section (#60) | 2 hours | Better onboarding |
| Tests for discover + follow flows (#76) | 8 hours | Regression safety |

---

## Total Estimated Effort
All 20 listed pending tasks combined: approximately **16–20 developer days** at a comfortable pace, or **8–10 days** at full focus.

---

## Codegen Reminder
After any change to `lib/api-spec/openapi.yaml`, regenerate client code:
```
pnpm --filter @workspace/api-spec run codegen
```

After any change to `lib/db` schema:
```
cd lib/db && pnpm run push
```
