# Sky Journal — Documentation Package

**Generated:** July 2026
**App:** Sky Journal — dreamy minimalist journaling + manga + social app

---

## Files in This Package

| File | Contents |
|---|---|
| `01-product-overview.md` | Full product & business overview — what the app is, all features, tech stack, database tables, API routes |
| `02-work-completed.md` | Everything built and live in the codebase — mobile app, API server, admin panel, libraries |
| `03-pending-tasks.md` | All 20+ proposed tasks with descriptions, locations, effort estimates, and a priority matrix |
| `04-dependencies-and-errors.md` | All packages and libraries, known issues/warnings, environment variables, and a phased workload plan |
| `05-admin-workflow.md` | Admin panel current state, how to run seasonal events end-to-end, and remaining admin work |

---

## Quick Summary

**What's built:** A full mobile app (iOS/Android/Web) with private journaling, public manga storytelling, character customisation, AI companion (Drift), real-time campfire rooms, direct messages, a rewards/shop system, seasonal events, and a separate admin dashboard.

**What's pending:** ~20 proposed improvements — mostly polish, real-time reliability, data validation fixes, admin season tooling, and social feature enhancements.

**Biggest gaps right now:**
1. A TypeScript type error in notification handling (`_layout.tsx`)
2. SSE connections don't auto-reconnect after app goes to background
3. No error states when API responses are corrupted
4. Season countdown not shown to players yet
5. Test coverage for discover and follow/unfollow flows

**Estimated remaining effort:** 16–20 developer days for all pending tasks.

---

## Architecture at a Glance

```
Sky Journal (monorepo — pnpm workspaces)
├── artifacts/sky-journal       ← Expo mobile app (iOS + Android + Web)
├── artifacts/api-server        ← Express REST API (all backend logic)
├── artifacts/admin             ← React admin dashboard
├── artifacts/mockup-sandbox    ← Design/canvas preview server
├── lib/db                      ← Drizzle ORM + PostgreSQL schema
├── lib/api-spec                ← OpenAPI 3.1 contract (source of truth)
├── lib/api-client-react        ← Generated React Query hooks
└── lib/api-zod                 ← Generated Zod validation schemas
```

**Auth:** Clerk (JWT) — mobile app uses @clerk/expo, server uses @clerk/express, admin uses @clerk/clerk-react

**Database:** PostgreSQL with Drizzle ORM — tables: character, follows, journal_entries, stories, outfits, messages, campfire, notifications, rewards, events, gallery, reports, sticker_reactions

**AI:** Anthropic Claude — powers the Drift AI companion and admin event inventory generation
