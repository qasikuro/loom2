# Sky Journal — Work Completed

This document summarises all major features and systems that have been built and are live in the codebase.

---

## Mobile App (`artifacts/sky-journal`)

### Authentication
- Clerk sign-in and sign-up screens (email + password)
- Email verification flow
- Auth token bridge — auto-registers token getter with API context once Clerk loads
- Protected tab bar (redirects to sign-in if not authenticated)
- Per-user data isolation: every API query filters by authenticated Clerk userId

### Navigation (Expo Router, file-based)
- Root stack with modal routes
- Auth stack (sign-in, sign-up)
- Tab bar: Home, Journal, Create, Discover, Profile
- Modals: create journal entry, create outfit, campfire, messages, story reader, vibe post
- Nested stacks: story/[id], user/[userId], campfire rooms, guide pages, panel editor, chapter editor

### Tab Bar Design
- Floating pill style (borderRadius 28, absolute positioning)
- BlurView on iOS, solid background on Android
- Floating Create centre button (purple, 52×52, floats above bar)
- Feather icons pre-loaded via useFonts()
- Labels: Home, Journal, (none), Discover, Profile

### Home Screen
- Time-aware sky gradient (GradientSky component — dawn/day/dusk/night)
- Weather widget (ambient, matches Sky aesthetic)
- Quick action buttons
- Recent journal entries preview
- XP flash / reward banner notifications

### Journal
- Three entry types: Diary, Friend Log, Moment
- Text + mood + optional photo
- Always private — no visibility toggle
- Rotating daily writing prompt
- JournalCard component (italic text, mood badge, optional thumbnail)
- LogCard component for friend/moment logs
- Create modals: create-journal-entry, create-friend-log, create-moment-log, quick-moment

### Stories / Manga Creator
- Multi-panel chapter builder (up to 12 panels)
- MangaPanelEditor component — per-panel image + narration
- ChapterEditor and PanelEditor screens
- Public/private toggle
- Story reader: immersive full-screen manga viewer
- "Witness" instead of like
- Witnessed count, saved count
- My Stories page
- Saved Stories page

### Character Profile
- Inline editable name, bio
- @username handle with real-time availability check (regex + API)
- Trait chips (add/remove, autocomplete suggestions)
- Profile visibility toggle
- Mood selector
- Progress bars with constellation map
- XP system with levels and milestone modals
- Title system (earned titles, active title display)
- Profile effects (cosmetic overlays)

### Outfit Log
- Grid of outfit cards
- Photo, name, description, vibe tags
- Public/private per outfit
- Outfit detail view

### Discover Feed
- For You tab: scored ranking algorithm (follow boost, mood match, engagement, recency)
- New tab: date sorted
- Vibes tab: filter by mood category (8 moods)
- People tab: debounced username/name search with Follow/Unfollow toggle
- Optimistic follow/unfollow (local state updates immediately)
- DiscoverCard component with mosaic panel preview
- WitnessMosaic component

### Drift (AI Companion)
- Dedicated Drift tab
- Claude-powered chat in calm, Sky-like voice
- Private conversations (never shared)
- Chat history per session

### Campfire Rooms
- Named room entry
- Real-time messages via SSE
- See who is in the room
- Sticker reactions on messages
- VibeStickerPicker component
- ChatStickerAnimation component

### Messages (DMs)
- Conversation list
- Per-user DM thread screen
- SSE live updates
- ResonateButton (positive message reaction)

### Rewards & Shop
- RewardBalance component (shows Stars, Aura, Shards)
- ShopModal — browse and purchase cosmetic items
- XPFlash component — animated XP gain display
- RewardBanner — slide-in/out notification for rewards earned
- MilestoneModal — celebrate level-up moments
- Purchase history screen
- Wardrobe (owned cosmetic items)

### Notifications
- In-app notification feed
- Push notification token registration
- Notification types: witness, DM, follow, event grant

### Stickers & Reactions
- Sticker reactions on campfire messages and story panels
- VibeStickerPicker component
- ChatStickerAnimation component
- StickerReactions DB schema

### Gallery
- Personal media gallery of uploaded images

### Guides
- In-app guide pages (admin-managed content)
- Guide route: guide/[userId].tsx

### Reports
- ReportSheet component — users can flag content
- Reports submitted to API

### Constellation Map
- Visual XP/progress map (ConstellationMap + ConstellationStarSheet)
- StarNode components with animations
- Animated progress bars (ProfileEffect)

### Themes
- ThemeContext with multiple visual themes
- Theme-aware journal and story cards

### Onboarding
- OnboardingOverlay component for first-time users
- AppSplashScreen

### Error Handling
- ErrorBoundary and ErrorFallback components
- Skeleton loading states
- Toast notifications

### Data Persistence
- AsyncStorage cache (offline-first load)
- API sync on auth ready
- Optimistic mutations throughout
- Cache keys versioned (character_v2, stories_v1, journal_v2, outfits_v1, etc.)

### Image Handling
- expo-image-picker integration
- Base64 → POST /api/upload → served from /api/images/
- ImageSourceSheet (pick from library or camera)
- CropImageModal
- iOS modal stacking delay (400ms) to prevent picker stall

### Sound
- SoundContext for ambient audio

---

## API Server (`artifacts/api-server`)

### Middleware
- Clerk JWT auth middleware (global)
- requireAuth per-route guard
- getUserId helper

### All Routes Live
- Character, journal entries, stories, outfits, follows, discover
- Messages, campfire, SSE stream
- Drift (Claude AI chat)
- Notifications, push token registration
- Rewards, shop, purchase history
- Sticker reactions
- Gallery
- Guide content
- Reports
- Weather
- Upload (base64 → file)
- Admin: events CRUD, AI inventory generation, grant to users
- Admin: users list, content review, reports queue

### AI (Anthropic Claude)
- Drift companion chat (`routes/drift.ts`)
- Event inventory generation (`routes/admin-events.ts`)

### Real-time (SSE)
- `/api/stream` — persistent SSE connection per user
- Events: new message, new notification, campfire presence

---

## Admin Panel (`artifacts/admin`)

### Pages Built
- **Dashboard** — overview stats
- **Users** — list all users, view profiles
- **Content** — review public stories and reports
- **Events** — full CRUD for seasonal events
  - List grouped by status (Active → Drafts → Ended)
  - Create/Edit form with AI inventory generation
  - Per-item inline editor
  - Grant to All Users with two-tap confirm
- **Reports** — review flagged content

### Auth
- Clerk auth with admin role check
- First-admin self-claim flow
- Access denied screen

---

## Database (`lib/db`)

### Schema Files Live
- character, follows, journal_entries, stories, outfits
- messages, campfire, notifications, rewards
- events, gallery, reports, sticker_reactions
- index (barrel export)

### ORM
- Drizzle ORM with PostgreSQL
- Migrations via `pnpm run push` in lib/db

---

## Shared Libraries

| Library | Purpose |
|---|---|
| `lib/db` | Drizzle ORM schema + DB client |
| `lib/api-spec` | OpenAPI 3.1 contract (openapi.yaml) |
| `lib/api-client-react` | Generated React Query hooks |
| `lib/api-zod` | Generated Zod validation schemas |

---

## Design System

- Palette: lavender `#C8B8E8`, sky blue `#B8D4F0`, warm gold `#C8A84B`
- Background: soft cream `#F8F4EE`
- Primary: muted purple `#6B5B95`
- Night sky: deep navy `#1A1630`
- Time-aware gradient: dawn / day / dusk / night
- All Sky-themed iconography and naming
