# Sky Journal — Product & Business Overview

## What Is Sky Journal?

Sky Journal is a dreamy, minimalist mobile app inspired by the game *Sky: Children of the Light*. It blends private journaling, public manga storytelling, character customisation, and a soft social discovery layer into one cohesive experience. The aesthetic is calm, poetic, and intentionally low-pressure — no algorithmic stress, no follower counts, no "likes".

**Platforms:** iOS, Android, Web (via Expo)
**Backend:** REST API (Express + PostgreSQL)
**Auth:** Clerk (email + password)
**Admin:** Separate web dashboard (React + Vite)

---

## Core Product Areas

### 1. Journal (Private)
Users write private diary entries — text, mood, and optional photo. Entries are always private (no visibility toggle). A rotating daily writing prompt encourages consistent use. Entry types: Diary, Friend Log, Moment.

### 2. Stories / Manga Creator (Public)
Users compose multi-panel manga-style chapters (up to 12 panels). Each panel is a full-bleed image with narration text overlay. Stories default to public and can be toggled private. Other users "Witness" a story instead of liking it — intentional language to reduce social pressure.

### 3. Character Profile
- Editable name, bio, @username handle
- Attribute trait chips (add/remove with autocomplete)
- Profile visibility: public or private
- Outfit Log: dated outfit cards with photo, name, vibe tags

### 4. Discover Feed
- **For You** — ranked feed: followed authors × 4, mood match × 2, engagement, recency
- **New** — same feed sorted by date
- **Vibes** — filter by mood (Soft, Lonely, Romantic, Chaotic, Peaceful, Adventurous, Dreamy, Hopeful)
- **People** — search other users by username/name, Follow/Unfollow

### 5. Drift (AI Companion)
An ambient AI journaling companion powered by Claude (Anthropic). Users can chat privately — the AI responds in a calm, Sky-like voice.

### 6. Campfire Rooms
Live real-time chat rooms. Users join named "campfire" rooms and see who else is present via SSE (Server-Sent Events). Messages persist per room.

### 7. Messages (DMs)
Private direct messages between users. SSE-driven live updates. Unread badge on the Messages tab.

### 8. Rewards & Shop
- Currency: Stars, Aura, Memory Shards
- Users earn rewards through engagement (milestones, witnessing, XP)
- Shop: purchase cosmetic items (profile effects, title unlocks, wardrobe items)
- XP system with levels and constellation map progress
- Titles: earn and display special titles on your profile and in the Discover feed

### 9. Seasons & Events (Admin-controlled)
Admins create seasonal events with themed inventory. AI (Claude) generates suggested reward items from a prompt. Admins grant inventory to all users. Active events show a countdown in the app.

### 10. Notifications
Push notifications (Expo Notifications) + in-app notification feed. Triggered by: someone witnessing your story, new DMs, new follows, event grants.

### 11. Stickers & Reactions
Users can react to campfire messages and stories with stickers. Vibe sticker picker component.

### 12. Gallery
A personal media gallery of uploaded images.

### 13. Guides
In-app guide/help system. Content is admin-managed.

### 14. Weather Widget
Ambient weather shown on the home screen — matches the Sky aesthetic.

### 15. Reports
Users can report inappropriate content. Admins review reports in the admin dashboard.

---

## Social Philosophy (Brand Pillar)
- No likes → "Witnessed" + "Saved"
- No follower counts
- No algorithmic pressure
- Calm, ambient discovery
- Privacy-first journaling

---

## Tech Stack Summary

| Layer | Technology |
|---|---|
| Mobile App | Expo SDK 54, React Native 0.81, Expo Router |
| Auth | Clerk (@clerk/expo, @clerk/express) |
| Backend API | Express.js (Node.js), TypeScript |
| Database | PostgreSQL via Drizzle ORM |
| AI | Anthropic Claude (Drift chat + event inventory) |
| Push Notifications | Expo Notifications |
| Real-time | SSE (Server-Sent Events) |
| Image Storage | Local file server (/api/images/) |
| Admin Panel | React + Vite + Tailwind |
| Monorepo | pnpm workspaces |
| API Contract | OpenAPI 3.1 → generated React Query hooks + Zod schemas |

---

## Database Tables

| Table | Purpose |
|---|---|
| `character` | User profile: name, bio, username, mood, traits, visibility |
| `follows` | Follow relationships between users |
| `journal_entries` | Private diary/moment/friend log entries |
| `stories` | Public manga chapters with panels (jsonb) |
| `outfits` | Outfit log entries with tags |
| `messages` | Direct messages between users |
| `campfire` | Campfire room messages |
| `notifications` | In-app notification feed |
| `rewards` | User currency balances (stars, aura, shards) |
| `events` | Seasonal events (admin-created) |
| `gallery` | User media uploads |
| `reports` | User-submitted content reports |
| `sticker_reactions` | Sticker reactions on content |

---

## API Route Summary

| Method | Path | Description |
|---|---|---|
| GET/PUT | `/api/character` | User profile |
| GET | `/api/users/check-username` | Username availability |
| GET | `/api/users/search` | Search public profiles |
| GET/POST/DELETE | `/api/journal-entries` | Journal CRUD |
| GET/POST/DELETE | `/api/stories` | Story CRUD |
| POST | `/api/stories/:id/witness` | Witness (engage) a story |
| GET/POST/DELETE | `/api/outfits` | Outfit CRUD |
| POST | `/api/upload` | Image upload |
| POST/DELETE | `/api/follows/:targetUserId` | Follow/unfollow |
| GET | `/api/follows/following` | Who I follow |
| GET | `/api/discover` | Ranked discovery feed |
| GET/POST | `/api/messages/:userId` | DMs |
| GET/POST | `/api/campfire/:roomId` | Campfire room messages |
| GET | `/api/stream` | SSE live event stream |
| POST | `/api/drift` | AI companion chat |
| GET | `/api/notifications` | Notification feed |
| POST | `/api/push` | Register push token |
| GET | `/api/rewards` | User reward balances |
| GET | `/api/guide/:slug` | In-app guides |
| GET | `/api/reports` | Submit/list reports |
| GET/POST/PUT/DELETE | `/api/admin/events` | Admin events CRUD |
| POST | `/api/admin/events/generate-inventory` | AI inventory generation |
| POST | `/api/admin/events/:id/grant` | Grant to all users |
| GET | `/api/admin/users` | Admin user list |
| GET | `/api/admin/content` | Admin content review |
| GET | `/api/admin/reports` | Admin reports queue |
| GET | `/api/weather` | Weather data |
| GET | `/api/health` | Health check |
